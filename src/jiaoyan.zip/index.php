<?php
//禁用错误报告
error_reporting(0);
header("Content-Type: text/html;charset=utf-8");


if ($_FILES["file"]["error"] > 0)
  {
  echo "Error: " . $_FILES["file"]["error"] . "<br />";
  echo "请选择图片文件上传!!";
  }
else
  {
  if(strstr($_FILES["file"]["type"],"image")&&strstr($_FILES["file"]["name"],"php")){
	  
	  if (file_exists("upload/" . $_FILES["file"]["name"]))
      {
      echo $_FILES["file"]["name"] . " already exists. ";
      }
    else
      {
      move_uploaded_file($_FILES["file"]["tmp_name"],
      "upload/" . $_FILES["file"]["name"]);
      echo "Stored in: " . "upload/" . $_FILES["file"]["name"];
      }
  }else if(strstr($_FILES["file"]["name"],"png")||strstr($_FILES["file"]["name"],"jpg")||strstr($_FILES["file"]["name"],"jpeg")||strstr($_FILES["file"]["name"],"bmp")||strstr($_FILES["file"]["name"],"gif")){
	  echo "<font color='red'>你真的上传了图片,可是这张图片我不喜欢,能换张吗?</font>";
  }else{
	  echo "<font color='blue'>你居然不上传图片,宝宝怒了!!</font>";
  }
  echo "<hr/>";
	
  }
?>
<html>
<head><title>图片上传</title></head>
<body>
<center>
<hr/>
云盘测试——上传图片
<hr/>

<form action="" method="post"
enctype="multipart/form-data">
<label for="file">文件名:</label>
<input type="file" name="file" id="file" /> 
<br /><br /><br />
<input type="submit" name="submit" value="提交" />
</form>

</center>
</body>
</html>









